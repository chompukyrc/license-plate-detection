import tensorflow as tf
from flask import Flask, request, jsonify, send_file, send_from_directory
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input as preprocess_input_mob
from tensorflow.keras.applications.inception_v3 import preprocess_input as preprocess_input_inc
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img
import matplotlib.pyplot as plt
import cv2
import numpy as np
import easyocr
import os
from flask_cors import CORS
import base64
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.get_logger().setLevel('INFO')

app = Flask(__name__)
CORS(app)
cars_image = os.listdir("./images")
modelsName = os.listdir("./models")
reader = easyocr.Reader(['th'], gpu=False)

try:
    cars_image.remove(".git_keep")
except:
    print("An exception occurred")
try:
    modelsName.remove(".git_keep")
except:
    print("An exception occurred")
try:
    cars_image.remove(".DS_Store")
except:
    print("An exception occurred")
try:
    modelsName.remove(".DS_Store")
except:
    print("An exception occurred")
 

models = []
for x in modelsName:
    print("Loading " + x + " model...")
    models.append(load_model("./models/" + x))
    print("Load " + x + " model done")


def object_detection(model, path):
    # read image
    image = load_img(path)  # PIL object
    image = np.array(image, dtype=np.uint8)  # 8 bit array (0,255)
    image1 = load_img(path, target_size=(224, 224))
    # data preprocessing
    # convert into array and get the normalized output
    image_arr_224 = img_to_array(image1)/255.0
    h, w, d = image.shape
    test_arr = image_arr_224.reshape(1, 224, 224, 3)
    # make predictions
    coords = model.predict(test_arr)
    # denormalize the values
    denorm = np.array([w, w, h, h])
    # print(coords, denorm)
    coords = coords * denorm
    coords = coords.astype(np.int32)
    # draw bounding on top the image
    xmin, xmax, ymin, ymax = coords[0]
    pt1 = (xmin, ymin)
    pt2 = (xmax, ymax)
    crop_img = image[int(ymin):int(ymax), int(xmin):int(xmax)]
    result = reader.readtext(crop_img, detail=0)
    # print(pt1, pt2)
    cv2.rectangle(image, pt1, pt2, (0, 255, 0), 3)
    cv2.imwrite("./results/output.jpg",
                cv2.cvtColor(crop_img, cv2.COLOR_RGB2BGR))
    cv2.imwrite("./results/output2.jpg",
                cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
    return image, crop_img, coords[0], result


@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"


@app.route("/api/get-data")
def getCars():
    return jsonify({
        "cars": cars_image,
        "models": modelsName
    })


@app.route("/api/predict", methods=['POST'])
def predict():
    content = request.json
    # path = './dataset/images/294707ec-1697729862.012733.jpg'
    image, plate, cods, ocr_result = object_detection(models[content['model']], os.path.join(
        "./images/", cars_image[content['image']]))

    return jsonify({"cods": cods.tolist(), "image": "results/output.jpg", "plate": "results/output2.jpg", "ocr": ocr_result})


@app.route('/images/<path:path>')
def send_image(path):
    return send_from_directory('images', path)


@app.route('/results/<path:path>')
def send_result(path):
    return send_from_directory('results', path)


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0")
