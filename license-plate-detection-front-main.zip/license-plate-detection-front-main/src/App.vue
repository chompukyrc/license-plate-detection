<template>
    <div class="bg-red-100 h-screen w-screen text-center p-8 text-white">
        <div class="text-3xl bg-pink-500 py-4 rounded-xl font-extrabold">
            Car License Plate Detection
        </div>
        <div class="flex my-5">
            <div
                class="border-2 border-pink-600 text-pink-600 py-4 w-1/2 rounded-xl mr-4 text-xl"
            >
                <div class="font-bold text-2xl my-2">
                    โมเดลที่ต้องการ: {{ picked }}
                </div>
                <div class="flex">
                    <div v-for="(model, index) in models">
                        <input
                            type="radio"
                            :id="index"
                            :value="model"
                            v-model="picked"
                        />
                        <label :for="index" class="m-4">{{ model }}</label>
                    </div>
                </div>
                <!-- <input
                    type="radio"
                    id="two"
                    value="MobilenetV2"
                    v-model="picked"
                />
                <label for="two" class="m-4">MobilenetV2</label> -->
            </div>
            <div
                class="text-2xl border-2 border-pink-600 text-pink-600 py-4 w-1/2 rounded-xl ml-4 flex justify-center items-center"
            >
                <label for="cars">Choose a picture:</label>
                <select
                    name="cars"
                    id="cars"
                    v-model="picture"
                    class="text-pink-600 mx-4 rounded-3xl text-lg p-1"
                >
                    <option
                        v-for="(car, index) in pictures"
                        :value="car"
                        :key="car"
                    >
                        {{ car }}
                    </option>
                </select>
            </div>
        </div>

        <div class="bg-pink-500 h-2/3 rounded-3xl">
            <p>ภาพ {{ picture }}</p>

            <img :src="'http://localhost:4444/images/' + picture" />
            <div v-if="predictResult" class="flex">
                <div>
                    {{ predictResult?.cods }}
                    <img
                        :src="'http://localhost:4444/' + predictResult?.plate"
                    />
                </div>
            </div>
            <div class="flex justify-end">
                {{ predictResult?.ocr }}
                <img
                    class="w-32 mr-12"
                    :src="'http://localhost:4444/' + predictResult?.image"
                />
            </div>
        </div>
        <div class="flex justify-end mt-5">
            <button
                class="bg-pink-300 mx-2 w-40 h-12 mb-5 rounded-3xl hover:bg-pink-500 hover:scale-105"
                @click="resetClick"
            >
                RESET
            </button>
            <button
                class="bg-pink-300 mx-2 w-40 h-12 mb-5 rounded-3xl hover:bg-pink-500 hover:scale-105"
                @click="sendPredict()"
            >
                SUBMIT
            </button>
        </div>
    </div>
</template>

<script>
import axios from "axios";

export default {
    data() {
        return {
            picked: "",
            pictures: [],
            models: [],
            picture: [],
            predictResult: null,
            loading: false,
        };
    },
    methods: {
        async getCarPic() {
            try {
                const res = await axios({
                    url: "http://localhost:4444/api/get-data",
                    method: "GET",
                });

                console.log(res.data);
                const { cars, models } = res.data;
                this.pictures = cars;
                this.models = models;

                this.picked = this.models[0];
                this.picture = this.pictures[0];
            } catch (error) {
                console.log(error);
            }
        },
        async sendPredict() {
            try {
                if (this.loading) return;
                this.loading = true;
                const modelIndex = this.models.findIndex(
                    (e) => e === this.picked
                );
                const picureIndex = this.pictures.findIndex(
                    (e) => e === this.picture
                );
                const res = await axios({
                    url: "http://localhost:4444/api/predict",
                    method: "POST",
                    data: {
                        model: modelIndex,
                        image: picureIndex,
                    },
                });

                const { cods, image, plate, ocr } = res.data;
                // console.log(atob(image));
                this.predictResult = {
                    cods,
                    image,
                    plate,
                    ocr,
                };

                console.log(this.predictResult);
            } catch (error) {
                console.log(error);
            } finally {
                this.loading = false;
            }
        },
        resetClick() {},
    },
    mounted() {
        this.getCarPic();
    },
};
// import HelloWorld from "./components/HelloWorld.vue";
</script>

